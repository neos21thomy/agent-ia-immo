# STORYBOARD — LIMO Reel (1080×1920, 30 fps, 20 s)

Monolithic composition (`index.html`) : the phone persists across chapters 1–4,
so one timeline keeps the screen swaps continuous.

## Frame 1 — Hook
status: outline
src: index.html#s-hook (0.00–2.75 s)
blueprint: kinetic-type-beats · rules: svg-path-draw (clock ring), waterfall-entry
beat: « 8H00. » slams inside a cyan clock ring that sweeps; « TA JOURNÉE / EST DÉJÀ TRIÉE. »

## Frame 2 — Brief du matin
status: outline
src: index.html#s-app (2.55–6.55 s)
blueprint: device-surface-showcase + grid-card-assemble · rules: waterfall-entry, press-release-spring, svg-path-draw
beat: phone rises (status bar 8:00) ; « Aujourd'hui » : 5 priority cards cascade ; card 1 checked, counter 5 → 4.

## Frame 3 — Chat & dictée
status: outline
src: index.html#s-app (6.55–10.55 s)
blueprint: prompt-type-submit-generate + agent-progress-theater · rules: card-morph-anchor (clip-path), sine-wave-loop, svg-path-draw
beat: listening pill (waveform) expands into the user bubble ; LIMO answers (serif) ; receipt rows check off.

## Frame 4 — Estimation
status: outline
src: index.html#s-app (10.55–13.95 s)
blueprint: dataviz-countup · rules: counting-dynamic-scale, stat-bars-and-fills, spring-pop-entrance
beat: 389 000 € counts up ; range bar 372 000–405 000 € ; confidence ring 86 % ; source chips.

## Frame 5 — Détecteur de ventes
status: outline
src: index.html#s-app (13.95–16.80 s)
rules: svg-path-draw (streets), spring-pop-entrance (pins), sine-wave-loop (pulses), press-release-spring
beat: map draws ; 3 new DPE pins (F / G / E) pulse ; « Nouvelle piste » card slides up.

## Frame 6 — End card
status: outline
src: index.html#s-end (16.80–20.00 s)
blueprint: logo-assemble-lockup · rules: svg-path-draw, spring-pop-entrance, ambient-glow-bloom
beat: house-network logo draws itself ; LIMO wordmark ; « Ton chef de cabinet IA. » ; CTA « 1 mois gratuit · sans CB » ; app.leadengineai.fr
