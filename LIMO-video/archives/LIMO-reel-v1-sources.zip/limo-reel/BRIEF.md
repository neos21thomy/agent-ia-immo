---
workflow: general-video
flow: automation
storyboard: no
message: "LIMO, ton chef de cabinet IA : ta journée est déjà triée."
destination: instagram-reels
aspect: "9:16"
language: fr
audience: conseillers immobiliers (mandataires, agents) — France
length: 20s
angle: démonstration épurée de l'appli, un module par chapitre
---

## Intent

Reel Instagram en motion design « ultra épuré et précis » pour l'application LIMO
(app.leadengineai.fr), réalisé avec HyperFrames (demande de Thomy).

## Stated (dit par l'utilisateur)

- Vidéo motion design pour Reels Instagram, ultra épurée et précise.
- Matière fournie : bilan LIMO, pub « Analyseur de dossier » (charte LIMO + écrans réels),
  vidéo UGC IA (écran d'accueil), mascotte robot et logo maison-réseau (images collées).

## Inferred / defaulted (proposé par Claude, non contredit)

- Accroche : « 8H00. Ta journée est déjà triée. »
- Pas de voix off ; pas de musique intégrée (son tendance ajouté dans Instagram).
- Chapitres : Brief du matin → Chat & dictée → Estimation → Détecteur de ventes → end card.
- CTA : « 1 mois gratuit · sans CB » + app.leadengineai.fr (conditions du bilan du 21/07/2026).
- Données 100 % fictives (compte démo « Jean & Marie TYPE ») — aucune donnée client réelle.
- Logo maison-réseau et O du wordmark redessinés en SVG (fichiers image non fournis).

## Assets

- Charte : fond sombre, cyan #00C6FC, titres condensés (Anton), wordmark LIM + O cyan.
- UI app (relevée au pixel) : fond #121218/#18122A, cartes #1E1830, violet #785AFC,
  bulle utilisateur #1278FC, réponses LIMO en serif.

## Notes

- Éviter « grade notaire » ; aucun chiffre non prouvable.
- Zones de sécurité Reels : contenu clé entre y≈150 et y≈1500, marge droite libre.
